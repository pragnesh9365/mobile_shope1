package com.admin;
import com.Db.Dbconnect;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/AddProductSrv")
public class addproductservlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data
        String name = request.getParameter("name");
        String type = request.getParameter("type");
        String info = request.getParameter("info");
        double price = Double.parseDouble(request.getParameter("price"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        
        // Handle file upload (image)
        Part filePart = request.getPart("image");
        InputStream imageInputStream = filePart.getInputStream();
        PrintWriter out1=response.getWriter();
        // Database connection
        //Connection conn = null;
        PreparedStatement pstmt = null;
        Connection conn=Dbconnect.getconnection();
        out1.print(conn);
        try {
            
            // Insert data into database
            String sql = "INSERT INTO product (name, type, description, price, quantity, image) VALUES (?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, type);
            pstmt.setString(3, info);
            pstmt.setDouble(4, price);
            pstmt.setInt(5, quantity);
            pstmt.setBlob(6, imageInputStream);
            pstmt.executeUpdate();
            
            // Redirect to a success page or show success message
            response.sendRedirect("success.html");
        
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions appropriately (e.g., show error message)
            response.sendRedirect("error.html");
            
        } finally {
            // Close resources
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
                if (imageInputStream != null) imageInputStream.close();
            } catch (SQLException | IOException e) {
                e.printStackTrace();
            }
        }
    }
}
