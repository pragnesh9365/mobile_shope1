/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.servlet;
import com.Db.Dbconnect;
import java.sql.*;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name = "loginservlet", urlPatterns = {"/loginservlet"})
public class loginservlet extends HttpServlet {


   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username=request.getParameter("username");
        String password=request.getParameter("password");
         
         PrintWriter out1=response.getWriter();
       
        Connection conn=Dbconnect.getconnection();
        try {
             PreparedStatement ps1 = conn.prepareStatement("select * from user where name=? and password=?");
                ps1.setString(1, username);
                ps1.setString(2, password);
                
                ResultSet rs1 = ps1.executeQuery();
                if(rs1.next())
                {
                    String name=rs1.getString("name");
                    if(name.equals("admin"))
                    {
                         response.sendRedirect("adminHome.jsp");
                    }
                    else
                    {
                         response.sendRedirect("userHome.jsp");
                    }
                    
                }else
                {
                    HttpSession session=request.getSession();
                    session.setAttribute("error1", "username password is wrong");
                    response.sendRedirect("login.jsp");
                    
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
